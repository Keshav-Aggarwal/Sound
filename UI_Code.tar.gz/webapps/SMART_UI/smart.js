$(document).ready(function () {
  product_store = {}
  server_host='http://127.0.0.1:5000';
  $("#output_row").hide();
  $('#submit_form').click(function() {
    ais_img = $("input[id='ais_img']").val()
	  $("#output_row").hide();
     {
      req_data = {'AIS_IMG': ais_img, 'BRAND':'data', 'ITEM':'item'};
      var formData = new FormData();
      formData.append('AIS_IMG',document.getElementById('ais_img').files[0]);
      $('.analysis').hide();
      $(".gif").show();
      $.ajax({
        url: server_host + '/smart/analyze',
        cache: false,
        type: "POST",
        data: formData,
        timeout: 120000,
        processData: false,
        contentType: false,
        success: function (resp) {
          json_resp = $.parseJSON(resp)
	  console.log(json_resp);
	  $('#output').html(json_resp);
	  $("#output_row").show();
          $(".gif").hide();
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
          console.log('textStatus' + textStatus + ' errorThrown' +errorThrown)
          $(".gif").show();
        }
      });
    }
  });
});
